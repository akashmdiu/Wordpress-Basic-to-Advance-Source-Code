

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Basic PHP</title>
    <style>
        body{
            background:#ccc
        }
        .header{
            text-align:center;padding:10px 0; background:#ddd; width:70%;margin:0 auto;font-family:ubuntu
        }
        .body{
            text-align:center;width:70%;margin:0 auto;min-height:520px;margin-top:10px;padding:0px;background:#fff;
        }
    </style>
</head>
<body style="">
    <h1 class="header">Basic PHP</h1> 
    <section class="body">
    <br/><br/>
        <!-- part-4 source code-->
        <?php
            echo("I love my counrty");
            echo "<br/>";
            echo "This is akash";
            echo 'akash';

            $name = "akash";
            echo $name;
            // <!-- end part-4 source code-->

           
            
        ?>
        
    </section>
</body>
</html>